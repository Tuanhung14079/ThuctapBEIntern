﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heart
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = ("My first app in c#");
            Console.WriteLine("******************************************");
            Console.WriteLine("***   0 0 0 0    0 0 0 0    ");
            Console.WriteLine("***  0 0 0 0 0 0 0 0 0 0 0  ");
            Console.WriteLine("***0 0 0 0 0 0 0 0 0 0 0 0 0");
            Console.WriteLine("***0 0 0 0 0 0 0 0 0 0 0 0 0");
            Console.WriteLine("***  0 0 0 0 0 0 0 0 0 0 0  ");
            Console.WriteLine("***    0 0 0 0 0 0 0 0 0    ");
            Console.WriteLine("***      0 0 0 0 0 0 0      ");
            Console.WriteLine("***        0 0 0 0 0        ");
            Console.WriteLine("***         0 0 0 0         ");
            Console.WriteLine("***           0 0           ");
            Console.WriteLine("***            0            ");


        }
    }
    }


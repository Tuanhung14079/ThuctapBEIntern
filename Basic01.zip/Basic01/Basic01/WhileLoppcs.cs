﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class WhileLoppcs
    {
        static void Main(string[] args)
        {
            //Vòng alp56 while sử dụng khi ko biết chính xác số lần lặp
            // Sẽ kết thúc khi đạt điều kiện false
            //For và while có thể sử dụng thay thế cho nhau
            //While(ĐK) {
            //Nội dung cần lặp
            //}
            // Nhập số n và in ra các số lẻ <n
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 0;
            int sum = 0;
            int x=0;
            while (i<n)
            {
                if (i%2==1)
                {
                    Console.WriteLine(i);
                }
                i++;
            }
            while (x < n) //Tổng các số <n
            {
                 sum += x;
                 x++;
            }
            Console.WriteLine($"1+.....+n={sum}");



        }
    }
}

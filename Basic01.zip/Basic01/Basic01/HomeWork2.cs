﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class HomeWork2
    {
        static void Main(string[] args)
        {
            //Bài 2.0: Nháp
            Console.WriteLine("------------------Bai 12---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            Console.Write("Nhap so n3 : ");
            int n3s = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");
            if (n3s >= 0)
            {
                long f0 = 0, f1 = 1, fn = 0;
                if (n3s < 2)
                {
                    Console.WriteLine($"f{n3s} = " + n3s);
                }
                for (int i = 2; i <= n3s; i++)
                {
                    fn = f0 + f1;
                    f0 = f1;
                    f1 = fn;
                    // fn=f(n-1)+f(n-2)
                }
                Console.WriteLine($"f{n3s} = {fn}");

            }
            else
            {

                Console.WriteLine("Nhap so tu nhien n");
            }
            //Bài 2.1: Nhập số tự nhiên n sau đó in ra các số chẵn, lẻ <= n.
            Console.WriteLine("------------------Bai 1---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a > 0)
            {

                Console.WriteLine("Các số chẳn là : ");
                for (int b = 1; b <= a; b++)
                {

                    if (b % 2 == 0)
                    {
                        Console.Write(b+ " ");



                    }
                    
                }
                Console.WriteLine(" ");

                Console.WriteLine("Các số chẳn là : ");
                for (int b = 1; b <= a; b++)
                {

                    if (b % 2 == 1)
                    {
                        Console.Write(b + " ");



                    }

                }
            }

            else
            {
                Console.WriteLine("Nhap lai so khac nhe");
            }
            //Bài 2.2: Nhập số tự nhiên n rồi tính tổng: S = 1 + 2 + ... +n.
            Console.WriteLine("------------------Bai 2---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int b1 = Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            for (int i1 = 0; i1 <= b1; i1++) // dùng while cũng dc 
            {
                sum += i1;
            }
            Console.WriteLine($"Tong cua cac so tu nhien n la : {sum}");
            //Bài 2.3: Nhập số tự nhiên n rồi tính tổng(lưu ý phép chia các số nguyên):
            //S = 1 +1/2+1/3+.....1/n
            Console.WriteLine("------------------Bai 3---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int c1 = Convert.ToInt32(Console.ReadLine());
            Double sum2 = 0;
            for (int i2 = 1; i2 <= c1; i2++)
            {
                sum2 += 1 / (double)i2;

            }
            Console.WriteLine("giá trị tong la: " + sum2);

            //Bài 2.4: Nhập vào một số tự nhiên n rồi tính:
            //a) Trung bình cộng các số tự nhiên không lớn hơn n.
            //b) Trung bình cộng các số tự nhiên lẻ không lớn hơn n.
            //c) Trung bình cộng các số tự nhiên chẵn không lớn hơn n.
            Console.WriteLine("------------------Bai 4---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int d1 = Convert.ToInt32(Console.ReadLine());
            int sum1 = 0;
            int sum3 = 0;
            int sum4 = 0;

            double tb2 = 0;
            double tb3 = 0;
            double tbc1 = 0;
            double tbl1 = 0;
            for (int i = 1; i <= d1; i++)
            {
                sum1 += i;
                if (i % 2 == 0)
                {
                    sum3++;
                    tb2 += i;
                    tbc1 = (double)tb2 / (double)sum3;

                }
                else
                {
                    sum4++;
                    tb3 += i;
                    tbl1 = (double)tb3 / (double)sum4;
                }

            }
            Console.WriteLine("trung binh Tong cac so la:  " + (double)sum1 / (double)d1);
            if (sum3 > 0)
            {
                Console.WriteLine($"Tong le cua so {d1} la:{tbl1}");
            }
            else
            {
                Console.WriteLine("Tong le =0");
            }
            if (tbc1 > 0)
            {
                Console.WriteLine($"Tong chan cua so {d1} la:{tbc1}");
            }
            else
            {
                Console.WriteLine("Tong chan=0");
            }


            //Bài 2.5: Nhập số nguyên dương n và tính tổng: S = 1 + 1.2 + 1.2.3 + ... +1.2.3...n.
            Console.WriteLine("------------------Bai 5---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int e = Convert.ToInt32(Console.ReadLine());
            int S = 1;
            int sgt = 0;
            if (e>0)
            {
                for (int i = 1; i <= e; i++)
                {
                    S = S * i;
                    sgt += S;

                }
                Console.WriteLine("Tong tich cac so hang la : " + sgt); 
            }
            else
            {
                Console.WriteLine("Vui long nhap so nguyen duong");
            }
            
            //Bài 2.6: Nhập số tự nhiên n, k rồi tính tổng các số tự nhiên không lớn hơn n và
            //chia hết cho k.
            Console.WriteLine("------------------Bai 6---------------------------");
            Console.WriteLine("Nhap vao ban phim 2 so nguyen bat ki");
            int n1 = Convert.ToInt32(Console.ReadLine());
            int k1 = Convert.ToInt32(Console.ReadLine());
            int sum01 = 0;
            if (k1 == 0)
            {
                Console.WriteLine("So ko hop le nhap lai ");
            }
            else
            {


                for (int i = 0; i <= n1; i++)
                    if (i % k1 == 0)
                    {
                        sum01 += i;

                    }
                Console.WriteLine("Tong cac so tu nhien chia het cho k la : " + sum01);
            }

            //Bài 2.7: Nhập số tự nhiên n rồi liệt kê các ước số tự nhiên của nó.Số đó bao
            //nhiêu ước? 9 chia hết cho 3 thì 3 là ước số của 9.
            Console.WriteLine("------------------Bai 7---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int n2 = Convert.ToInt32(Console.ReadLine());
            int dem=0;
            if (n2 > 0)
            {


                for (int i = 1; i <= n2; i++)
                {
                    if (n2 % i == 0)
                    {
                        Console.Write(i+" ");
                        dem++;
                    }
                }
                Console.WriteLine("\n Tong so uoc cua bien la : "+dem); // \n là xuống` dòng
            }
            else
            {
                Console.WriteLine("So ko hop le vui long nhap lai");
            }
            //Bài 2.8: Viết chương trình tìm ước chung lớn nhất và bội số chung nhỏ nhất của
            //hai số nguyên a, b. ( Giaỉ như sau : Nếu cả a và b điểu bằng 0 thì ko tồn tại UCLN,TCNN
            //Nếu a hoặc b=0 sẽ ko có bội chung nh3o nhất do ko có số nào chia hết cho 0 còn ước chung lớn nhất là số còn lại khác 0
            //
            Console.WriteLine("------------------Bai 8---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int a3 = Convert.ToInt32(Console.ReadLine());
            int b3 = Convert.ToInt32(Console.ReadLine());
            if (a3 >= 0 && b3 >= 0)
            {
                if (a3 == 0 & b3 == 0)
                {
                    Console.WriteLine("Khong ton tai uoc chung lon nhat va boi chung nho nhat");
                }
                else if (a3 == 0 || b3==0)
                {
                    Console.WriteLine("Khong co boi uoc chung");
                    Console.WriteLine("Uoc chung lon nhat" + (a3 == 0 ? b3 : a3));
                }
                else
                {
                    int boi = a3 * b3;
                    //Cách 1 
                    while(a3!=b3)
                    {
                        if (a3 > b3)
                        {
                            a3 -= b3;
                        }
                        else
                        {
                            b3 -= a3;
                        }
                    }
                    Console.WriteLine("UCLN = "+a3);
                    Console.WriteLine("Boi chung nho nhat: "+boi/a3);
                    //Cách 2 chia lấy dư
                //    while (b3!=0)
                //    {
                //        int xs = b3;
                //        b3=b3 % a3;
                //        a3 = xs;
                //    }
                //    Console.WriteLine(a3);

               }
            }
            else
            {
                Console.WriteLine("Nhap a,b la so ngueyn duong");
            }
            //Bài 2.9: Viết chương trình nhập số nguyên n và kiểm tra n có phải số nguyên tố
            //hay không.
            Console.WriteLine("------------------Bai 9---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int a44 = Convert.ToInt32(Console.ReadLine());
            if (a44 < 2)
            {
                Console.WriteLine("Vui long nhap lai so nguyen duong");
            }
            else
            {
                bool nguyento = true;
                for (int i = 1; i <= Math.Sqrt(a44); i++)
                {


                    if ( a44 % i == 0 )
                    {
                        nguyento = false;
                        break;
                    }  
                    
                }
                if (nguyento) //có thể hiểu là mặc định là true rùi
                {
                    Console.WriteLine($"{a44} Chinh la so nguyen to ");
                }
                else
                {
                    Console.WriteLine($"{a44} khong phai la so nguyen to ");
                }
            }
            //Bài 2.10.Viết chương trình phân tích một số nguyên thành các thừa số nguyên
            //tố.Ví dụ: Số 28 được phân tích thành 2 x 2 x 7.
            Console.WriteLine("------------------Bai 10---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int a5 = Convert.ToInt32(Console.ReadLine());
            if (a5>1)
            {
                Console.Write($"{a5}= ");
                int i1 = 2;
                while (a5>1)
                {
                    if (a5%i1 ==0)
                    {
                        Console.Write(i1);
                        if (a5!=i1)
                        {
                            Console.Write("x");
                        }
                        a5 /= i1;

                    }
                    else
                    {
                        i1++;
                    }
                }

            }
            else
            {
                Console.WriteLine("Nhap lai so nguuyen to");
            }
            Console.WriteLine();
            //Bài 2.11.Viết chương trình liệt kê n số nguyên tố đầu tiên. ( khi nhập n thì sẽ hiện 4 số nguyên tố là 2 3 4 7 11)
            Console.WriteLine("------------------Bai 11---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int a6 = Convert.ToInt32(Console.ReadLine());
            if (a6>0)
            {
                int m = 2;
                int dem2 = 0;
                while (dem2 <a6) // chạy tới khi nào dem  a6 thì ngưng
                {
                    bool songueynto = true;
                    for (int i = 2; i < Math.Sqrt(m); i++)
                    {
                        if (m%i==0)
                        {
                            songueynto = false;
                            break;
                        }
                    }
                    if (songueynto)
                    {
                        Console.Write(m+" ");
                        dem2++;
                    }
                    m++;
                }
            }
            else
            {
                Console.WriteLine("Vui long nhap vao so duong");
            }
            //Bài 2.12.Dãy số Fibonacci được định nghĩa như sau: F0 = 0, F1 = 1; Fn = Fn - 1 +
            //Fn - 2 với n >= 2.Hãy viết chương trình tìm số Fn.
            Console.WriteLine("------------------Bai 12---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            Console.Write("Nhap so n3 : ");
            int n3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("");
            if (n3>=0)
            {
                long f0 = 0, f1 = 1, fn=0;
                if (n3<2)
                {
                    Console.WriteLine($"f{n3} = "+n3);
                }
                for (int i = 2; i <= n3; i++)
                {
                    fn = f0 + f1;
                    f0 = f1;
                    f1 = fn;
                    // fn=f(n-1)+f(n-2)
                }
                Console.WriteLine($"f{n3} = {fn}");

            }
            else
            {

                Console.WriteLine("Nhap so tu nhien n");
            }
            


            //Bài 2.13.Một số được gọi là số thuận nghịch nếu ta đọc từ trái sang phải hay từ
            //phải sang trái số đó ta vẫn nhận được một số giống nhau.Hãy nhập một số và
            //kiểm tra xem số đó có phải số thuật nghịch hay không(ví dụ số: 558855)( là số mà khi đảo lại giá trị ko đổi) .
            Console.WriteLine("------------------Bai 13---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int nhap1 = Convert.ToInt32(Console.ReadLine());
            if (nhap1>0)
                {
                int m4 = nhap1;
                int dao = 0;
                while(m4>0)
                {
                    dao = dao * 10 + m4 % 10;
                    m4 /= 10;
                }
                if (m4== dao)
                {
                    Console.WriteLine($"{nhap1} la so thuan nghich");
                }
                else
                {
                    Console.WriteLine($"{nhap1} ko la so thuan nghich");
                }
                }
            //Bài 2.14: Nhập số tự nhiên n rồi tính n!theo công thức:
            //n! = 1 nếu n = 0
            //n! = n * (n - 1) * (n - 2) * ... *2 * 1 nếu n > 0
            Console.WriteLine("------------------Bai 14---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int n14 = Convert.ToInt32(Console.ReadLine());
            long gt = 1;
            if (n14 >0)
            {
                for (int i = n14; i >=1; i--)
                {
                    gt = gt * i;
                }
                Console.WriteLine($"Giai thua cua {n14} la : {gt}");
            }
            else
            {
                Console.WriteLine("Vui long nhap so >0)");
            }
            //Bài 2.15: Hãy viết chương trình tính tổng các chữ số của một số nguyên bất kỳ.
            //Ví dụ: số 8545604 có tổng các chữ số là: 8 + 5 + 4 + 5 + 6 + 0 + 4 = 32
            Console.WriteLine("------------------Bai 15---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int n15 = Convert.ToInt32(Console.ReadLine());
            if (n15<0)
            {
                n15 *= -1;
            }
            while (n15>0)
            {
                int tong = 0;
                //int du = n14;

                for (int i = 0; i < n15; i++)
                {
                    //du %= 10;
                    //tong += du;
                    // du /=10 ;
                    tong += n15 % 10;
                    n15 /= 10;

                }
                Console.WriteLine($"Tong cac so {n14} =  {tong}");
            }
            
           
            //Bài 2.16: Nhập vào 2 số tự nhiên m<n. Hãy liệt kê các số chính phương trong
            //đoạn[m, n]. Có bao nhiêu số chính phương trong đoạn đó? ( số chính phương là số có căn bặc 2 lâ số nguyên )
            Console.WriteLine("------------------Bai 16---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen m bat ki ");
            int m16 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap vao ban phim so nguyen n bat ki ");
            int n16 = Convert.ToInt32(Console.ReadLine());
            if (m16 >=0 && n16 >=0)
            {
                int start = (int)Math.Sqrt(m16);
                int end =(int)Math.Sqrt(n16);
                for (int i = start; i <= end; i++)
                {
                    Console.WriteLine(i*i + " ");
                }
                Console.WriteLine("So luong ket qua thoa man "+(end-start));
            }
            else
            {
                Console.WriteLine("Vui long nhap la so nguyen");
            }
            //Bài 2.17: Nhập 2 số tự nhiên m, n rồi kiểm tra xem chúng có nguyên tố cùng
            //nhau không(Hai số nguyên tố cùng nhau là 2 số có USCLN là 1).
            Console.WriteLine("------------------Bai 17---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            //Bài 2.18: Nhập một số thực a > 0(ví dụ a = 0.00001) rồi tính số π theo công thức:
            //            π = 4 * ∑ (−1)
            //𝑘
            //1
            //2𝑘+1
            //𝑛
            //𝑘= 0
            //giá trị của biểu thức trên được thực hiện đến khi
            //1/(2𝑛+1) ≤ 𝑎.
            Console.WriteLine("Nhap do chinh xac (VD: 0,00000001)");
            double a18 = Convert.ToDouble(Console.ReadLine());
            int k = 0;
            double sum18 = 0;
            double tmp18 = 1.0 / (2 * k + 1);
            while (true)
            {
                sum18 += Math.Pow(-1, k) * tmp18;
                k++;
                if(tmp18 <= a)
                {
                    break;
                }
            }
            Console.WriteLine("PI = "+ (4*sum));
            //Bài 2.19: Nhập một số a > 0(ví dụ a = 0.00001) và một số thực x rồi tính 𝑒
            //𝑥
            //:
            //𝑒^𝑥
            //= ∑
            //𝑥
            //𝑘
            //𝑘!
            //𝑛
            //𝑘= 0
            //Điều kiện dừng: |
            //𝑥
            //𝑛
            //𝑛!
            //| ≤ 𝑎.
            Console.WriteLine("Nhap vao x : ");
            double x19 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Nhap do chinh xac : ");
            double a19= Convert.ToDouble(Console.ReadLine());

            int k19 = 0;
            double sum19 = 0;
            double xMuK = x19;
            long g = 1;
            double tmp19 = 1.0 / g;
            while(true)
            {
                sum19 += tmp19;
                k19++;
                xMuK = Math.Pow(x19, k);
                g *= k19;
                tmp19 = xMuK / g;
                if (tmp19 <=a19)
                {
                    break;
                }
            }
            Console.WriteLine("e^x = "+sum19);
        }
     }
}

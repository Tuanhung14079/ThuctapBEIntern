﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class ClassString
    {
        static void Main(string[] args)
        {
            string a ="    Hello world";
            Console.WriteLine(a.Length); // sẽ trả về chiều dài của chuỗi
            Console.WriteLine(a.ToUpper()); // sẽ viết hoa hết các chữ   đây là 1 fuction có chức năng nên phải ()
            Console.WriteLine(a.ToLower().Trim()); // sẽ viết thường hết
            Console.WriteLine(a.Trim()); // Trim sẽ xóa đi các khoảng trắng dư 2 bên
            Console.WriteLine(a.Contains("o")); // tìm kiếm trong chuỗi có chữ O ko có phận biệt viết hoa viết thường
            Console.WriteLine(a.IndexOf("o")); // tìm xem kí tự o xuất hiện ở vị trí nào đầu tiên trong chuỗi 
            Console.WriteLine(a.ToString());


        }
    }
}

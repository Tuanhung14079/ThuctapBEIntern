﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class ToString
    {
        //Trong c#, tostring() là một phương thức của đối tượng object. phương thức này trả về một chuỗi đại diện cho đối tượng đó.

        //ý nghĩa của tostring() trong c# là:

        //chuyển đổi một đối tượng thành một chuỗi.
        //tạo một chuỗi đại diện cho một đối tượng.
        static void Main(string[] args)
        {

            int x = 10;
            string strs = x.ToString();
            Console.WriteLine(strs); // Output: 10
            //Trong ví dụ trên, phương thức ToString() được sử dụng để chuyển đổi biến x, có kiểu int, thành một chuỗi. Chuỗi được trả về là "10".

            //Phương thức ToString() có thể chấp nhận một chuỗi tham số để chỉ ra cách mà đối tượng sẽ tự định dạng khi chuyển về dạng chuỗi. Ví dụ:
            DateTime dt = new DateTime(2023, 9, 24);
            string str = dt.ToString("dd/MM/yyyy");

            Console.WriteLine(str); // Output: 24/09/2023
                                    //            trong ví dụ trên, phương thức ToString() được sử dụng để chuyển đổi biến dt, có kiểu DateTime, thành một chuỗi định dạng theo ngày/ tháng / năm.
                                    //                Chuỗi được trả về là "24/09/2023".

            //Tất cả các đối tượng trong C# đều kế thừa từ đối tượng Object, 
            //vì vậy phương thức ToString() luôn được định nghĩa sẵn cho tất cả các đối tượng. 
            //Tuy nhiên, các lớp con có thể ghi đè lại phương thức ToString() để cung cấp chuỗi đại diện cho lớp đó hợp lý hơn.
            //        }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class For
    {
        static void Main(string[] args)
        {
            // Vòng lập For  for(khoi_tao;dieu_kien;buoc_nhay) // for dùng ; chứ ko phải , // điều kiện là khi thỏa đk true sẽ chạy típ tới khi nào  false thì ngưng
            //hiện thị các biến số lẻ <=n
            //Console.WriteLine("Nhap vao so b: ");
            //int b = Convert.ToInt32(Console.ReadLine()); 
            //Console.WriteLine("Hihi");
            //for(int i=0;i<=b;i++) // đk i<=b là i sẽ chạy đến khi <=b sẽ ngưng 
            //{
            //    if(i%2==1)
            //     {
            //     Console.WriteLine("so la: "+i);





            // for (i = 0; i <= 2; i += 2) (Thực hiện nhảy 2 bước)
            //    }
            //}

            Console.WriteLine("Nhap vao so x đến y: ");
            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            for (int z = x; z <= y; z++)
            {
               sum += z;
            }
            Console.WriteLine($"sum cua {x} đến {y} la: {sum}");

        }


        }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class retrurnvalue
    {
        static void Main()
        {
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            int sum = a + b;
            //Cách 1 
            Console.WriteLine( " C1: Tong a+b = "+ sum);
            // Cách 2
            
            Console.WriteLine(" C2 :Tong a+b= {0}", sum); // {0} tự gán giá trị mặc dịnh đầu tiên cho nó cho nó
            //Cach 3 :
            Console.WriteLine($"C3 : Tong {a}+ {b}= {sum}");


            //Trong ngôn ngữ C#, ký tự $ có thể có nhiều ý nghĩa khác nhau, tùy thuộc vào ngữ cảnh sử dụng.

            //Ký hiệu tiền tố
            //Ký tự $ có thể được sử dụng như một ký hiệu tiền tố để xác định một biến hoặc hằng số là một tham chiếu đến một đối tượng.Ví dụ:

            //C#
            //int $a = 10; // $a là một tham chiếu đến đối tượng int với giá trị 10


        //    Ký hiệu hậu tố
        //                Ký tự $ có thể được sử dụng như một ký hiệu hậu tố để truy cập một thành viên hoặc phương thức của một đối tượng. Ví dụ:

        //    C#
        //    class Person
        //{
        //    public string Name { get; set; }
        //    public int Age { get; set; }
        //            }

            ////        Person p = new Person();
            ////        p.Name = "John Doe";
            ////p.Age = 30;

            //Console.WriteLine($"Tên của người là: {p.Name}"); // In ra: Tên của người là: John Doe
            //Console.WriteLine($"Tuổi của người là: {p.Age}"); // In ra: Tuổi của người là: 30

            //Vui lòng thận trọng khi sử dụng mã.Tìm hiểu thêm
            //Ký hiệu trong chuỗi
            //Ký tự $ có thể được sử dụng trong chuỗi để chèn một biến hoặc biểu thức. Ví dụ:

            //C#
            //int a = 10;
            //        string b = "Giá trị của a là: $a";

            //        Console.WriteLine(b); // In ra: Giá trị của a là: 10
            //Vui lòng thận trọng khi sử dụng mã.Tìm hiểu thêm
            //Ký hiệu trong định danh
            //Ký tự $ có thể được sử dụng trong định danh để tạo ra các định danh có ý nghĩa hơn. Ví dụ:

            //C#
            //class Person
            //        {
            //            public string $Name { get; set; }
            //        public int $Age { get; set; }
            //}

            //Person p = new Person();
            //p.$Name = "John Doe";
            //p.$Age = 30;

            //Console.WriteLine($"Tên của người là: {p.$Name}"); // In ra: Tên của người là: John Doe
            //Console.WriteLine($"Tuổi của người là: {p.$Age}"); // In ra: Tuổi của người là: 30
            //Vui lòng thận trọng khi sử dụng mã. Tìm hiểu thêm
            //Ngoài ra, ký tự $ còn được sử dụng trong một số tính năng nâng cao của ngôn ngữ C#, chẳng hạn như:

            //Chuyển đổi kiểu dữ liệu
            //Lập trình phản xạ
            //Lập trình hướng đối tượng
            //Để biết thêm thông tin về ý nghĩa của ký tự $ trong các ngữ cảnh cụ thể, bạn có thể tham khảo tài liệu chính thức của ngôn ngữ C#

            //====================================== Math============================================
            

        }
    }
}


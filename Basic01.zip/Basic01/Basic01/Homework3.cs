﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class Homework3
    {
        static void Main(string[] args)
        {
            //Bài 3.1: Nhập vào hai số nguyên dương m, n.Vẽ ra màn hình hình chữ nhật bằng
            //các dấu *kích thước m x n. Ví dụ với m = 4, n = 5:
            //*****
            //*****
            //*****
            //*****
            Console.WriteLine("Bai 3.1");
            Console.WriteLine("Nhap so m vao : ");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap so n vao");
            int n = Convert.ToInt32(Console.ReadLine());
            if (m>0 && n>0)
            {
                for (int i = 1; i <=m; i++)
                {
                    for (int j = 1; j <=n; j++)
                    {
                        Console.Write(" * ");
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Nhap m,n hop le ");
            }
            //Bài 3.2:Nhập vào hai số nguyên dương m, n. Vẽ hình chữ nhật rỗng bằng các dấu
            //*kích thước m x n. Ví dụ với m = 4, n = 5:
            //*****
            //*   *
            //*   *
            //*****
            Console.WriteLine("Bài 3.2");
            Console.WriteLine("Nhap vao so m");
            int m2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap so n vao");
            int n2 = Convert.ToInt32(Console.ReadLine());
            if (m2 > 0 && n2 > 0)
            {
                for (int i = 1; i <= m2; i++)
                {
                    for (int j = 1; j <= n2; j++)
                    {
                        if (i==1 || j==1 ||i==m2||j==n2)
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(" ");
                        }
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Vui long nhap lai m va n ");
            }

            //Bài 3.3: In ra màn hình bảng cửu chương theo chiều ngang
            Console.WriteLine("Bảng cuu chuong ");
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    Console.Write($"{i} x {j} = {i*j}\t");  // sẽ là cách 1 khoảng tab
                }
                Console.WriteLine();
            }
            //3.4 Nhập số nguyên dương h. Vẽ ra màn hình tam giác vuông góc trái dưới
            //chiều cao h.Ví dụ h = 4
            //*
            //**
            //***
            //****

            Console.WriteLine(" Bai 3.4");
            Console.WriteLine("Nhap so h");
            int h = Convert.ToInt32(Console.ReadLine());
            if (h>0)
            {


                for (int i = 1; i <= h; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write(" * ");
                    }
                    Console.WriteLine("\n");// \n+writeline là 2 lần xuống dòng
                }
            }
            else
            {
                Console.WriteLine("Nhap lai h");
            }

            //3.5 Nhập số nguyên dương h.Vẽ ra màn hình tam giác vuông góc trái trên chiều
            //cao h.Ví dụ h = 4:
            //****
            //***
            //**
            //*
            //for (int i = h3; i >= 1; i--)
            Console.WriteLine("Bai 3.5");
            Console.WriteLine("Nhap chieu cao h");
            int h3 = Convert.ToInt32(Console.ReadLine());
            if (h3 >0)
            {
                for (int i = h3; i >= 1; i--)
                {
                    for (int j = 1; j <=i; j++)
                    {
                        Console.Write(" * ");
                    }
                    Console.WriteLine("\n");
                }
            }
            else
            {
                Console.WriteLine("Nhap lai h");
            }

            //Console.WriteLine("Bai 3.5.2");
            //Console.WriteLine("Nhap chieu cao h");
            //int h4 = Convert.ToInt32(Console.ReadLine());
            //if (h4 > 0)
            //{
            //    for (int i = 1; i <= h4; i++)
            //    {
            //        for (int j = h4; j >= 1; j--)
            //        {
            //            Console.Write(" * ");
            //        }
            //        Console.WriteLine("\n");
            //    }
            //}
            //else
            //{
            //    Console.WriteLine("Nhap lai h");
            //}

            // 3.6 Nhập số nguyên dương h. Vẽ ra màn hình tam giác vuông góc phải dưới
            //chiều cao h.Ví dụ h = 4:
            //*
            //**
            //***
            //****
            Console.WriteLine("Bai 3.6");
            Console.WriteLine("Nhap chieu cao h :");
            int h6 = Convert.ToInt32(Console.ReadLine());
            if (h6 > 0)
            {
                for (int i = 1; i <= h6; i++)
                {
                    for (int j = 1; j<=i; j ++)
                    {
                        if(j <= (h - i))
                        {

                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Nhap lai h");
            }
            //3.7Nhập số nguyên dương h. Vẽ ra màn hình tam giác vuông góc phải trên
            //chiều cao h.Ví dụ h = 4:
             //****
             //***
             //**
             //*

            // 3.8 : Nhập số nguyên dương h sau đó in ra màn hình tam giác cân chiều cao h.
            //          Ví dụ h = 5:
            //*
            //***
            //*****
            //*******
            //*********

         //   Bài 3.9: Nhập số nguyên dương h sau đó in ra màn hình tam giác số đối xứng chiều
         //   cao h.Ví dụ h = 5:
         //       1
         //     1 2 1
         //   1 2 3 2 1
         //  1 2 3 4 3 2 1
         //1 2 3 4 5 4 3 2 1

        //    Bài 3.10: Nhập số nguyên dương h sau đó in ra màn hình tam giác cân rỗng chiều
        //    cao h. Ví dụ h = 5:
        //        1
        //       1  1
        //     1     1
        //    1       1
        //1 1 1 1 1 1 1 1 1

                //Bài 3.11: Cho hình vuông kích thước 7 x 7.Vẽ hình tim sử dụng vòng lặp. Ví dụ:
                // **  **
                //*******
                //*******
                 //*****
                  //***
                   //*

//Bài 3.12: Nhập vào hai số nguyên a<b. Hiển thị ra màn hình tất cả các số nguyên
//tố trong đoạn[a, b].
//Bài 3.13: Viết chương trình hiển thị ra màn hình các số thuận nghịch có 9 chữ số
        }
    }
}

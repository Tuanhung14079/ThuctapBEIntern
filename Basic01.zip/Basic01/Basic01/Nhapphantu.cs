﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
      class Nhapphantu
    {
            //static void String args[]" là khai báo của một phương thức có tên là "main".
            //Phương thức này có kiểu trả về là "void", tức là không trả về giá trị nào. 
            //Từ khóa "static" cho biết phương thức này có thể được truy cập mà không cần tạo ra một đối tượng của lớp chứa nó.
            //"String args []" là một tham số của phương thức "main". Tham số này đại diện cho một mảng các chuỗi, được sử dụng để truyền các tham số từ dòng lệnh vào chương trình.
        static void Main()
        {
            Console.WriteLine("Nhap số vào: ");
            Console.WriteLine("Nhap tuoi vào: ");
            String fullname = Console.ReadLine(); //Console.Readline() chỉ dùng cho string ko có lệnh truyền số
            //int hihi = Convert.ToInt32(Console.ReadLine()); // Covert là lệnh chuyển đổi dòng String conlone.Readline sáng int32
            int age = System.Int32.Parse(Console.ReadLine());// Parse cũng là 1 phương thức chuyển đổi ép kiểu  có thể ngắn gọn hơn là Int32.Parse("-105")
            int ne = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Số tuổi là :"+ fullname);
            Console.WriteLine("Số tuổi tui là :" + age);
            Console.WriteLine("Số tuổi tui là day ne :" + ne);
            //----------------------------------------In dữ liệu ra màn hình------------------------------------
            


        }
        

        
    }
       
}

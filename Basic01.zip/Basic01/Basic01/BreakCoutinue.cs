﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class BreakCoutinue
    {
        static void Main(string[] args)
        {
            int N = 100;
            int sum = 0;
            for (int i = 0; i < N; i++)
            {
                sum += i;
                if (sum %30==0)
                {
                    break; // break chỉ kết thúc vòng lặp chứa nó 
                }
            }
            Console.WriteLine($"SUM = {sum}");
            // vd2
            for (int i2 = 1; i2 <= 10; i2++)
            {
                if (i2%3==0)
                {
                    continue; // sẽ bỏ qua 3 6 9 mà vẫn tiếp tục
                    // contiunue thường sẽ đặt đầu chuỗi lệnh càn bỏ qua
                    // giúp bỏ qua những lệnh đủ đk là đến với lần lặp kế tiếp 
                }
                for (int j = 1; j <= 10; j++)
                {
                    Console.WriteLine($"{i2} x {j} ={ i2 * j}");
                    //if (i2==5) // SẼ BỎ BẢNG CỬU CHƯƠNG 5 RA CÒN CHẠY VẪN CHẠY )
                    //{
                    //    break;
                    //}
                    
                }
                Console.WriteLine();
                //if (i2%3==0) chỉ in đến bảng cửu chương 3
                //{
                //    break;
                //} vòng ;ặp chứa trực tiép break sẽ bị thoát

            }
        }
    }
}

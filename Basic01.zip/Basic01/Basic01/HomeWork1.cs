﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class HomeWork1
    {
        static void Main(string[] args)
        {
            //Bài 1.1: Viết chương trình in ra nội dung của một chuỗi kí tự nào đó nhập vào từ
            //bàn phím.Ví dụ: “I’m Iron Man”.
            Console.WriteLine("------------------Bai 1---------------------------");
            Console.WriteLine("Nhap vao ban phim chuoi bat ki");
            string a = Console.ReadLine();
            Console.WriteLine($"Chuoi nay la : {a}");
            //Bài 1.2: Nhập vào một số nguyên n, hãy cho biết số đó chẵn hay lẻ, chia hết cho 3
            //không, in kết quả kiểm tra ra màn hình.Mỗi kết luận trên một dòng.h
            Console.WriteLine("------------------Bai 2---------------------------");
            Console.WriteLine("Nhap vao ban phim so nguyen bat ki");
            int b = Convert.ToInt32(Console.ReadLine());
            if (b%2==1)
            {
                
                if(b%3==0)
                {
                    Console.WriteLine("Day la so le va co chia het cho 3:"+b);
                }
                else
                {
                    Console.WriteLine("Day la so le ko chia het cho 3: "+b);
                }
            }
            else
            {
                
                if (b % 3 == 0)
                {
                    Console.WriteLine("Day la so chan va co chia het cho 3: " + b);
                }
                else
                {
                    Console.WriteLine("Day la so chan ko chia het cho 3: "+b);
                }

            }
            //Bài 1.3: Nhập vào hai số nguyên a, b. In ra màn hình kết quả các phép tính +, -, *, /,
            //%.Lưu ý khi xử lý các phép chia sẽ cần ép kiểu, kiểm tra mẫu khác 0.Xuất kết
            //quả ra màn hình trên từng dòng.
            Console.WriteLine("------------------Bai 3---------------------------");
            Console.WriteLine("Nhap vao ban phim 2 so bat ki");
            Console.WriteLine("Nhap vao so c : ");
            int c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Nhap vao so d : ");
            int d = Convert.ToInt32(Console.ReadLine());
            int sum1 = c + d;
            Console.WriteLine("Tong 2 so la: "+sum1);
            double divide1 = c / d;
            Console.WriteLine("Thuong 2 so la: "+divide1);
            int subtract = c - d;
            Console.WriteLine("Hieu 2 so la: " + subtract);
            int multi = c * d;
            Console.WriteLine("Tich 2 so la : "+multi);
            //Bài 1.4: Nhập vào hai số nguyên a, b. So sánh xem số nào lớn hơn, số nào nhỏ hơn
            //hay hai số bằng nhau.In kết quả ra màn hình.
            Console.WriteLine("------------------Bai 4---------------------------");
            Console.WriteLine("Nhap vao ban phim 4 bat ki");
            int e = Convert.ToInt32(Console.ReadLine());
            int f = Convert.ToInt32(Console.ReadLine());
            if (e<f)
            {
                Console.WriteLine("So e nho hon so f ");
            }
            else if(e>f)
            {
                Console.WriteLine("So e lon hon so f ");
            }
            else
            {
                Console.WriteLine("So e la so f bang nhau");
            }
            //Bài 1.5: Hãy nhập 4 số nguyên a, b, c, d.Tìm giá trị nhỏ nhất trong đó và in ra màn
            //hình.Trong trường hợp 4 số bằng nhau thì in ra: không có số nhỏ nhất.
            Console.WriteLine("------------------Bai 5---------------------------");
            Console.WriteLine("Nhap vao ban phim 4 bat ki");
            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());
            int z = Convert.ToInt32(Console.ReadLine());
            int t = Convert.ToInt32(Console.ReadLine());
            int min = x;
            if (min > y) min = b;
            if (min > z) min = z;
            if (min > t) min = t;
            Console.WriteLine($"So be nhat la: {min}");
            //Bài 1.6: Hãy nhập 4 số nguyên bất kì sau đó lưu vào 4 biến a, b, c, d. Tìm giá trị lớn
            //thứ hai trong số chúng, in kết quả ra màn hình.Trường hợp tất cả cùng giá
            //trị thì không có số lớn thứ hai.
            Console.WriteLine("------------------Bai 6---------------------------");
            Console.WriteLine("Nhap vao ban phim 4 bat ki");
            int m = Convert.ToInt32(Console.ReadLine());
            int n = Convert.ToInt32(Console.ReadLine());
            int o = Convert.ToInt32(Console.ReadLine());
            int p = Convert.ToInt32(Console.ReadLine());
            int max = m;
            if (max < n) max = n;
            if (max < o) max = o;
            if (max < p) max = p;
            Console.WriteLine("So lon nhat la : "+max);
            //Bài 1.7: Viết chương trình nhập vào hai cạnh của hình chữ nhật và tính chu vi và
            //diện tích của hình chữ nhật đó.Hiển thị kết quả lên màn hình.
            Console.WriteLine("------------------Bai 7---------------------------");
            Console.WriteLine("Nhap vao ban phim 2 bat ki");
            double height = Convert.ToDouble(Console.ReadLine());
            double wight = Convert.ToDouble(Console.ReadLine());
            double chuvi = (height + wight) * 2;
            Console.WriteLine($"Chu vi hinh chu nhat la : {chuvi}");
            double dientich = height * wight;
            Console.WriteLine($"dien tich hinh chu nhat la : {dientich}");

            //Bài 1.8: Viết chương trình nhập bán kính của hình tròn và tính chu vi, diện tích hình
            //tròn đó.
            Console.WriteLine("------------------Bai 8---------------------------");
            Console.WriteLine("Nhap vao ban phim ban kinh bat ki");
            double r = Convert.ToDouble(Console.ReadLine());
            double dientich2 = Math.PI * Math.Pow(r,2);// trong c#dùng mủ ^  ta có thể dùng Math.Pow (x,2) để bình phương lên hoặc r*r khi trong hàm Math
            double chuvihinhtron = Math.PI * r * 2;
            Console.WriteLine("Dien tich hinh tron la : "+dientich);
            Console.WriteLine($"Chu vi hinh tron la: {chuvihinhtron}");
            //Bài 1.9: Giải và biện luận phương trình bậc nhất a𝑥 +b = 𝟎
            Console.WriteLine("------------------Bai 9---------------------------");
            Console.WriteLine("Nhap vao ban phim 2 bat ki");
            double k = Convert.ToDouble(Console.ReadLine());
            double L = Convert.ToDouble(Console.ReadLine());
            double X = -L / k;
            Console.WriteLine("Gia tri x cua phuong trinh bac 1 : "+X);
            //Bài 1.10: Giải và biện luận phương trình bậc 2 a𝑥^2 + b𝑥+ 1 + c = 𝟎
            Console.WriteLine("------------------Bai 10---------------------------");
            Console.WriteLine("Nhap vao ban phim 3 bat ki");
            double q = Convert.ToDouble(Console.ReadLine());
            double w = Convert.ToDouble(Console.ReadLine());
            double h = Convert.ToDouble(Console.ReadLine());
            double x1, x2,x3;
            double delta = Math.Pow(w, 2) - 4 * q * h;
            if (delta>0)
            {
                 x1 = Math.Sqrt(delta) / 2 * q;
                 x2 = -Math.Sqrt(delta) / 2 * q;
                // Cách 2 chúng ta dùng Math.Solve
                //float[] kq = System.Math.Solve(q, w, h); (chỉ dùng ở pb cao hơn)
                Console.WriteLine($"Gia tri x1 la : {x1}");
                Console.WriteLine($"Gia tri x1 la : {x1}");

            }
            else if(delta==0)
            {
                x3 = b / 2 * q;
                Console.WriteLine(" phuong trinh 1 nghiem voi gia tri la "+x3);
            }
            else
            {
                Console.WriteLine("Phuong trinh vo nghiem voi delta = " + delta);
            }
            //Bài 1.11: Nhập vào ba số thực a, b, c đều dương. Kiểm tra xem đó có phải là ba cạnh
            //của một tam giác hay không.Nếu có hãy chỉ ra đó là loại tam giác nào 
            //Nếu muốn 3 canh >0 có 2 cách 1 là dùng kiểu dữ liệu là unit 2 là lập điều kiện )
            Console.WriteLine("------------------Bai 11---------------------------");
            Console.WriteLine("Nhap vao ban phim 3 bat ki");
            double a1 = Convert.ToDouble(Console.ReadLine());
            double b1 = Convert.ToDouble(Console.ReadLine());
            double c1 = Convert.ToDouble(Console.ReadLine());
            while (a1 < 0 || b1 < 0 || c1 < 0)
            {
                Console.WriteLine("Vui long nhap lai so >0 nhe  )");
            }
            if (a1 + b1 > c1&& a1+c1 >b1 && c1+a1>b1)
            {
                if (a1 == b1 && b1 == c1)
                {
                    Console.WriteLine("Day la tam giac deu");
                }
                else if(a1 == b1 || a1 == c1||b1==c1)
                {
                    Console.WriteLine("Day la tam giac can");
                }
                else
                {
                    Console.WriteLine("Day la tam giac thuong");
                }
            
            }
            else
            {
                Console.WriteLine("Day khong phai la tam giac");
            }




        }
        
    }
}
            


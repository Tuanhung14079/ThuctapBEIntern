﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class SwichCase
    {
        static void Main(string[] args)
        {
            /* Cấu trúc Switch...case
             * swtich(expression)
             * {
             * case x:
             *  //Code block
             *  Break;
             * case y:
             * //Code block
             *  Berak;
             *  Default:     //Defaul là sẽ ko có bất k2i trường hợp trên case sẽ hành động
             *  //Code block
             *  Break;
             *  }
             */
            int Dayofweek = Convert.ToInt32(Console.ReadLine());
            switch (Dayofweek)
                {
                case 1:
                    Console.WriteLine("Hom nay là thu hai");
                 break;

                 case 2:
                    Console.WriteLine("Hom nay là thu ba");
                 break;
                case 3:
                    Console.WriteLine("Hom nay là thu tu");
                    break;
                case 4:
                    Console.WriteLine("Hom nay là thu nam");
                    break;
                case 5:
                    Console.WriteLine("Hom nay là thu sau");
                    break;
                case 6:
                    Console.WriteLine("Hom nay là thu bay");
                    break;
                case 7:
                    Console.WriteLine("Hom nay là chu nhat");
                    break;
                default:
                    Console.WriteLine("KO phai cac ngay trong tuan");
                break;
                }
        }
    }
}

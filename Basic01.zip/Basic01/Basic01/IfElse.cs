﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class IfElse
    {

        static void Main(string[] args)
        {
            int dayofweek = Convert.ToInt32(Console.ReadLine());
            if (dayofweek == 1)
            {
                Console.WriteLine("Tui phai di lam hoy");
            }
            else if (dayofweek==2)
            {
                Console.WriteLine("thu 3 roi");
            }
            else
            {
                Console.WriteLine("Cuoi tuan roi");
            }
            

        
            
        }
    }
    

}

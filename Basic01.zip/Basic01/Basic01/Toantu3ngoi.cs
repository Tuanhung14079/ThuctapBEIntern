﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class Toantu3ngoi
    {
        static void Main(string[] args)
        {
            //Variable =(Condition) ? expression  True : Expression False
            // Biến = (điều kiện xảy ra) ? giá trị nếu True dc gián  cho biến : Gía trị nếu False dc gán cho biến

            //C1
            int day = Convert.ToInt32(Console.ReadLine());
            string result = default;
            if(day <= 12)
            {
                result = "Hello";
            }
            else
            {
                result = "Haha";
            }
            Console.WriteLine("Cau tra loi la "+result);
            //C2
            String Res = (day >= 6) ? "Hihi" : "HAHA";
            Console.WriteLine(Res);
        }
    }
}

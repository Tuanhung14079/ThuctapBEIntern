﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello word");
            //Run :ctrl +f5
            //Ctrl + K + C: Comment một dòng code hoặc một đoạn code được chọn.

            //Ctrl + K + U: Bỏ comment một dòng code hoặc một đoạn code được chọn.
            //Start Debug:F5 (Khuyến nghị nên dùng Debug nhìu hơn)
            //các kết quả build : Sycceede:Thành Công ; Fail :Lỗi ;up-to-date:Vừa cập nhật;skipped:Bỏ qua
            // kí tự nhanh console.writeln() là cw tab tab
            Console.Title = ("My first app in c#"); //Đổi tên tiêu đề console
            Console.ForegroundColor = ConsoleColor.DarkRed;//đổi màu chữ
            Console.BackgroundColor = ConsoleColor.Yellow;//ĐỔI màu nền các chữ bên dưới
            Console.WriteLine("******************************************");
            Console.WriteLine("***   0 0 0 0    0 0 0 0    ***");
            Console.WriteLine("***  0 0 0 0 0 0 0 0 0 0 0   ***");
            Console.WriteLine("***0 0 0 0 0 0 0 0 0 0 0 0 0 ***");
            Console.WriteLine("***0 0 0 0 0 0 0 0 0 0 0 0 0 ***");
            Console.WriteLine("***  0 0 0 0 0 0 0 0 0 0 0   ***");
            Console.WriteLine("***    0 0 0 0 0 0 0 0 0     ***");
            Console.WriteLine("***      0 0 0 0 0 0 0       ***");
            Console.WriteLine("***        0 0 0 0 0         ***");
            Console.WriteLine("***         0 0 0 0          ***");
            Console.WriteLine("***           0 0            ***");
            Console.WriteLine("***            0             ***");
            Console.WriteLine("******************************************");
            Console.ForegroundColor = ConsoleColor.Blue;//sẽ chỉ thay đổi sang màu xanh những chữ sau dòng code này  tròn trên trái tim ko đổi.
            Console.BackgroundColor = ConsoleColor.Black;

            //biến trong C#
            //int-lưu trữ số nguyên(số nguyên), không có số thập phân, chẳng hạn như 123 hoặc - 123
            //double-lưu trữ các số dấu phẩy động, có số thập phân, chẳng hạn như 19,99 hoặc - 19,99
            //char-lưu trữ các ký tự đơn, chẳng hạn như 'a' hoặc 'B'.Giá trị Char được bao quanh bởi dấu ngoặc đơn
            //string-lưu trữ văn bản, chẳng hạn như "Xin chào thế giới".Giá trị chuỗi được bao quanh bởi dấu ngoặc kép
            //bool-lưu trữ các giá trị với hai trạng thái: đúng hoặc sai
            //const BIẾN HẰNG SỐ giúp  không cho người khác (hoặc chính bạn) ghi đè các giá trị hiện có
            //-------------------------------------------------------
            //phụ thuộc vào loại biến.Nếu kiểu có thể là null thì giá trị mặc định của nó sẽ là null.Các kiểu dễ đọc sẽ bắt đầu rỗng.
            //    loại
            //Complex(String, StringBuilder) = null
            //loại Numeric(int, số thập phân, đôi, byte) = 0
            //Boolean = false
            //DateTime = DateTime.MinValue(01 / 01 / 0001 00:00:00)
            //Char dùng để biểu diễn các kí tự đơn, ,mặc đinh5
            ////////////////////////////////////////////////////////////
            //Toán tử toán học +-*/ %(chia lấy dư) ++ (là tăng dần) -- (giảm dần)
            //Toán tử gán =,+=,-= *=, /=,%=,|=,^=,>>=,<<=
            //Toán tử so sánh == != >,<,>=,<=
            // Toán tử logic !,&&,||

            //Toán tử toán học +-*/ %(chia lấy dư) ++ (là tăng dần) -- (giảm dần)
            int a = 100;
            float b = 200.25f;
            float c = (float)200.25;
            //int sum = a + b; sẽ bị lỗi 
            float sum = (float)(a + b); // cách 1 ép kiểu
            Console.WriteLine(sum);
            //int sum = (int)(a + b); cách 2 ép kiểu
            // int -> long -> folat -> double
            // ép kiểu : có thể ép kiểu int sang doble,long,float nhưng long sang int sẽ lỗi
            // kiểu float phải có đơn vị f đằng sau số kiểu double thì ko cần
            string msg = "hello";
            string hehe = msg + a ; // khi khai báo biến là String nó sẽ tự mặc định vế sau là String dù nó là số hay chuỗi
            string haha = msg + a+b;// nếu muốn cộng tổng hai số a và b trc sau đó cộng chuỗi sau thì mở (a+b)
            string huhu = msg + (a + b);
            Console.WriteLine(hehe);
            Console.WriteLine(haha);
            Console.WriteLine(huhu);
            int x = 1, y = 2;
            double h = 2.3;
            Console.WriteLine(1.1*x/y);// vs số thực nó sẽ tự mặc định xuất ra keiu36 double nếu muốn kiểu float pah3i thêm f vô
            Console.WriteLine(1.1f * x / y);
            int div = (int)(h/y);
            Console.WriteLine(div);// nếu chia ra số thập phân mà keiu36 int sẽ bỏ phận thập phân
            Console.WriteLine(1.2 % 1.1);
            ++x;// x++ hay ++x thì vẫn như nhau , chỉ dc sử dụng vs biến
            --y;
            Console.WriteLine("x là :"+x+"Y là :"+y);
            //-------------------------------------------- Math-----------------------------------
            //Có thể coi namespace giống như 1 cái khu vực giới hạn náo đó 



        }
    }
}

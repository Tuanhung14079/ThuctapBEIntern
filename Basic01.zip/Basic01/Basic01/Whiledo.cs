﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class Whiledo
    {
        static void Main(string[] args)
        {
            //Khi ta muốn while thực hiện 1 lần dù đk nó có xảy ra hay ko
            int x = Convert.ToInt32(Console.ReadLine());
            do
            {
                Console.WriteLine(x);
                x++;
            }
            while (x < 100);
            
            

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class Phepgan
    {
        static void hihi()
        { 
            // = += -= *= %= /=
            int a = 300;
            int b = 100;
            a = b; // biến phải có giá trị mới gán dc
            Console.WriteLine(a);
            int c = default; // default/null sẽ =0  vs string sẽ là kí tự rỗng
            // a=a+b có thể viết gọn lại là a+=c
            //--------------------------------------------------------------------------------------
            // toán tử  logic
            // || (hoặc), && (và ) ,!( toán tữ phủ định)
            int x = 150, y = 201 ,z = 1000;
            bool result = (x % 2 == 0) || (y % 2 == 0);
            bool nah = (x % 2 == 0) && (y % 2 == 0);
            Console.WriteLine(result);
            Console.WriteLine(nah);
            Console.WriteLine(!result);
        }
    }
}

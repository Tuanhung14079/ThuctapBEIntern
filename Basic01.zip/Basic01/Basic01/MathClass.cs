﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basic01
{
    class MathClass
    {
        static void Maths()
        {
          
        }
        static void Main(string[] args)
        {
            // Math là 1 Class dùng để tính toán số học
            // có thể nhấn tổ crtl+k và crtl+c để  // chú thích
            // hũy chú thích ctrl +k vs ctrl+U
            //có 1 kiểu chú thích khác là :
            /*
             * Có thể chú thích bao nhiêu cũng dc
             * 
             */
            //namespace dc hiểu như 1 khu vực giới hạn nào đấy ( giới hạn ảo để quản lí chương trình )
            int max = Math.Max(10, 25); // sẽ so sánh giau74 2 số 10 và 25 nào lớn hơn xuất ra  sprt() là căn bậc 2
            //abs() trị tuyết đối
            //Math.PI là số pi
            //Max () Min().....
            Console.WriteLine($"Giá tri max là : {10},{25} ={max}");
            
        }
    }
}
